import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quest-details',
  templateUrl: './quest-details.component.html',
  styleUrls: ['./quest-details.component.css']
})
export class QuestDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
