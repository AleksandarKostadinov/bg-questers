import { Component } from '@angular/core';

@Component({
  selector: 'app-all-quests',
  templateUrl: './all-quests.component.html',
  styleUrls: ['./all-quests.component.css']
})
export class AllQuestsComponent {

  constructor() { }
}
