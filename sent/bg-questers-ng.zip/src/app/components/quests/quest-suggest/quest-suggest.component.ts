import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quest-suggest',
  templateUrl: './quest-suggest.component.html',
  styleUrls: ['./quest-suggest.component.css']
})
export class QuestSuggestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
