export class MedalViewModel {
  constructor(
    public id: string,
    public requirements: any,
    public name: string,
    public imgUrl: string,
    public material?: string
    ) { }
}
