export class SignUpInputModel {
  constructor(
    public email: string,
    public password: string
  ) { }
}
