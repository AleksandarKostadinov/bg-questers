export enum RaidStatus {
  NotStarted = 'Not Started',
  Active = 'Active',
  Finished = 'Finished'
}
